{
      'nome': 'csv_cidades',
      'uri': 'http://www.sefaz.ma.gov.br/resource/Cidades/{id}',
      'chaves': ['id'],
      'tipos': ['dbo:City'],
      'propriedade_de_dados': [{'nome': 'id', 'propriedades': ['dc:identifier'], 'tipo': 'xsd:string'}, {'nome': 'nome', 'propriedades': ['sfz:nome'], 'tipo': 'xsd:string'}],
      'propriedade_de_objeto': []
}