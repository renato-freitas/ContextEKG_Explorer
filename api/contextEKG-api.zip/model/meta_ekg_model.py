from typing import Union
from .resource_model import ResourceModel

class MetaEKGModel(ResourceModel):
  pass
  

  